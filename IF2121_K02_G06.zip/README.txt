# TOKEMON PRO&LOG

## PREREQUISITE
1. Download compiler GNU Prolog dan pastikan bisa dijalankan dengan metode apapun.

## RUN PROGRAM
1. Buka program GNU Prolog, dari Menu File pilih Console.
2. Pilih file tokemon.pl
3. Mulai dengan start untuk program baru atau loadGame(namaFile) untuk menge-load program yang pernah di save
4. Input 'map.' untuk menampilkan map
5. Input 'e.', atau 's.', atau 'w.', atau 'n.' untuk bergerak
6. Pemain dibebaskan bereksplorasi dalam permainan

## ABOUT DEVELOPER
Game ini dirancang sebagai satu Tugas Besar Logika Informatika 2121
Developer:
Ignatius David Partogi 13518014
Michelle Theresia 13518050
Jones Napoleon Autumn 13518086
Stefanus Stanley Yoga Setiawan 13518122

