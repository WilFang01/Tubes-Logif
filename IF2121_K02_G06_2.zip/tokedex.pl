/* tokedex(ID, Name, Type, MaxHealth, Level, Element, Attack, Skill) */

tokedex(1,bulsabaur,normal,200,1,grass,20,40).
tokedex(2,charamder,normal,200,1,fire,20,40).
tokedex(3,squirtrel,normal,200,1,water,20,40).
tokedex(100,sangemon,legendary,100000,90,water,3000,6000).
tokedex(101,probul,legendary,133243,90,fire,2843,4000).