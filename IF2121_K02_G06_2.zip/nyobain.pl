printY :-
    read(Esername),
    write(Esername).
